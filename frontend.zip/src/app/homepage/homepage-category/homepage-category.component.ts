import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { product } from 'src/app/products/product';
import { AlertService } from 'src/app/service/alert.service';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-homepage-category',
  templateUrl: './homepage-category.component.html',
  styleUrls: ['./homepage-category.component.css']
})
export class HomepageCategoryComponent implements OnInit {

  constructor(private router: Router, private service: ServiceService, private route: ActivatedRoute, private alertService: AlertService) { }
  products!: product[];
  flag:boolean=false;
  ngOnInit(): void {
    this.route.paramMap.subscribe((data) => {
      const dt = data.get("catergory_id")!
      this.products = this.searchbyCatrgory(dt)!;
    })
  }
  searchbyCatrgory(dt: string) {


    this.service.searchbyCatrgory(dt).subscribe(data => {

      if (!data) {
        this.flag = !this.flag;
        this.ngOnInit();
        return this.products = data;

      } else {
        return this.products = data;
      }

    })

  }

  viewdetails(event : any){
  const productID=event;
  this.router.navigate(['/productdetail' + `/${productID}`]);

  }
}
