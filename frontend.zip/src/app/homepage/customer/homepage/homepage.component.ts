import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from 'src/app/service/service.service';

@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor(private router: Router, private service: ServiceService, private route: ActivatedRoute) { }

  ngOnInit() {
    try {
      const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if (id && localStorage.getItem("currentUser")) {
       //do something here
        
      }

      else {
        this.router.navigate(['/login']);
      }
    }
    catch (error) {
      this.router.navigate(['/login']);

    }
  }


}
