import { TitleCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { ServiceService } from '../service/service.service';
import { user } from '../userprofile/user';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  currentUser!: user;
  email!: string;
  returnUrl!: string;
  LocalUser: any;
  constructor(private router: Router, private route: ActivatedRoute,
    private authenticationService: AuthenticationService, private service: ServiceService) {
      this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
  }

  ngOnInit(): void {

    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || 'profile';
  }
  logout() {
    this.authenticationService.logout();
    this.router.navigate(['/login']);
  }
  ShowProfilePage() {
    try {
      this.email = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if (this.email && localStorage.getItem("currentUser")) {
        this.router.navigate(['/profile' + `/${this.email}`])
      }
      else {
        this.router.navigate(['/login']);
      }
    } catch (error) {
      this.router.navigate(['/login']);
    }


  }

  searchproducts(event : Event){

    const selection= (event.target as HTMLInputElement).value;
    //console.log(['/product/'+selection]);
    //route it to product page...
    const catergory_id = selection.charAt(0).toUpperCase() + selection.slice(1);
    this.router.navigate(['/category' + `/${catergory_id}`]);
    
    console.log("Routed from header event to : " +['/category' + `/${catergory_id}`]);

  }
  
}
