import { product } from "../products/product";

export interface cart{
    _id:any;
    userid:any;
    product:product;
    quantity:any;
}