import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { product } from '../products/product';
import { ServiceService } from '../service/service.service';
import { cart } from './cart';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  constructor(private router: Router, private service: ServiceService, private route: ActivatedRoute) { }
  Order!:any;
  cartobj:any;
  product!:product;
  cart!:cart;
  listitem!:cart[];
  totalItems:any=3;
  totalprice:any=9497.00;
  flag:boolean=false;

  ngOnInit() {
    try{
    const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
    if(id && localStorage.getItem("currentUser")){
      this.cartobj={"userid":id}
      this.service.ViewCart(this.cartobj).subscribe(obj=>{
       this.listitem=obj;
       console.log(this.listitem);
      })
    }
    
    }
    catch(error){
console.log(error)
    }
    
    this.listitem.forEach(element => {
      this.totalprice = element.product.price*element.quantity;
      this.totalItems =element.quantity+this.totalItems;
    });

    
  }
  PlaceOrder(event: any) {
    try {
      const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if (id && localStorage.getItem("currentUser")) {
        const abc=((event.target as HTMLInputElement).value)
        const producttoBuy =this.listitem;
        console.log(producttoBuy);

        this.Order = {"userid":id, "cartitems": producttoBuy }
        console.log(this.Order);
        this.service.placeorder(this.Order).subscribe(obs => {
          if(obs.status==201){
            this.service.clearcart({"email":id}).subscribe(ob=>{
              if(ob.status==200){
                console.log("Order placed sucessfully")
                this.router.navigate(['/product']);
              }
            })
          }
          this.router.navigate(['/order']);
        })
      }

      else {
        this.router.navigate(['/login']);
      }
    }
    catch (error) {
      this.router.navigate(['/login']);

    }


  }

  CalculatePricce(event :Event){
    this.ngOnInit();
    const val= (((event.target) as HTMLDataElement).value);
    this.flag=!this.flag;
    
  }

 
}
