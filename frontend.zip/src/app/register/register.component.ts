import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';


import { AlertService } from '../service/alert.service';
import { ServiceService } from '../service/service.service';
import { user } from '../userprofile/user';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  paragraph=`Folly words widow one downs few age every seven. If miss part by fact he park just shew.
  Discovered had
  get considered projection who favourable. Necessary up knowledge it tolerably. Unwilling
  departure
  education is be dashwoods or an. Use off agreeable law unwilling sir deficient curiosity
  instantly. Easy
  mind life fact with see has bore ten. Parish any chatty can elinor direct for former. Up as
  meant widow
  equal an share least.

  Depart do be so he enough talent. Sociable formerly six but handsome. Up do view time they shot.
  He
  concluded disposing provision by questions as situation. Its estimating are motionless day
  sentiments
  end. Calling an imagine at forbade. At name no an what like spot. Pressed my by do affixed he
  studied.`
  //registerForm!: FormGroup;
  //loading = false;
  //submitted = false;
  
  constructor(private router: Router, private formBuilder: FormBuilder, private service: ServiceService, private route: ActivatedRoute, private alertService: AlertService) { }

  ngOnInit() {
  //   this.registerForm = this.formBuilder.group({
  //     firstName: ['', Validators.required],
  //     lastName: ['', Validators.required],
  //     username: ['', Validators.required],
  //     password: ['', [Validators.required, Validators.minLength(6)]]
  // });
  }
  //get f() { return this.registerForm.controls; }

  model: any = {};
  
  onSubmit() {
    
    try {
      this.model.role="user"
      this.service.register(this.model).subscribe(obs=>{
        if(obs.status===201){
          alert('Congratulations! ' + obs.message);
          this.router.navigate(['/login']);
          return;
        }
        else{
          alert('Failure !' + obs.message);
          this.model ={};
        
        }
        
      })
    } catch (error) {
      return;
    }
   
    
  }

}
