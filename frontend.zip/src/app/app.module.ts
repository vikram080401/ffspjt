import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/customer/homepage/homepage.component';
import { LoginComponent } from './login/login.component';
import { UserComponent } from './userprofile/user.component';
import { ProductsComponent } from './products/products.component';
import { UserdetailsComponent } from './userprofile/userdetails/userdetails.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { MustMatchDirective } from './_helpers/must-match.directive';
import { StaticpageComponent } from './staticpage/staticpage.component';
import { jwtTokenService } from './service/jwtToken.service';
import { CategoriesComponent } from './categories/categories.component';
import { HomepageCategoryComponent } from './homepage/homepage-category/homepage-category.component';
import { ProductDetailComponent } from './products/product-detail/product-detail.component';
import { CartComponent } from './cart/cart.component';
import { OrdersComponent } from './orders/orders.component';

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    LoginComponent,
    UserComponent,
    ProductsComponent,
    UserdetailsComponent,
    FooterComponent,
    HeaderComponent,
    RegisterComponent,
    MustMatchDirective,
    StaticpageComponent,
    CategoriesComponent,
    HomepageCategoryComponent,
    ProductDetailComponent,
    CartComponent,
    OrdersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [jwtTokenService],
  bootstrap: [AppComponent]
})
export class AppModule { }
