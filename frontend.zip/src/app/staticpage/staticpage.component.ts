import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-staticpage',
  templateUrl: './staticpage.component.html',
  styleUrls: ['./staticpage.component.css']
})
export class StaticpageComponent implements OnInit {
  
  constructor() { }

  ngOnInit(): void {
  }

}
