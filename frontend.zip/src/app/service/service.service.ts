import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { user } from '../userprofile/user';
import { AuthenticationService } from './authentication.service';
import { environment } from '../environments/environment'
import { product } from '../products/product';
import { cart } from '../cart/cart';


@Injectable({
  providedIn: 'root'
})
export class ServiceService {


  constructor(private http: HttpClient, authenticationService: AuthenticationService) { }
  user!: user[];
  usr!: user;

  getUsers(): Observable<any> {
    return this.http.get("http://localhost:5001/api/v1/users");
  }
  getUserDetails(email: any): Observable<any> {

    const usrget: {} = { email: email };
    return this.http
      .post<{ message: string }>("http://localhost:5001/api/v1/getuserDetails", usrget);

  }

  login(email: any, password: any): Observable<any> {
    return this.http.post("http://localhost:5001/api/v1/validateuser", { "email": email, "password": password })
  }

  register(userdata: user): Observable<any> {
    return this.http.post(`${environment.apiUrl}/register`, userdata);

  }
  updateUser(userdata: user): Observable<any> {
    return this.http.post(`${environment.apiUrl}/updateUser`, userdata);

  }

  updateUserProfilePics(email: string, image: String): Observable<any> {
    const profileData = { "email": email, "image": image }

    return this.http.post(`${environment.apiUrl}/updateUserProfilePics`, profileData);
  }
  getAllProductDetails():Observable<any> {
    return this.http.get(`${environment.apiUrl}/products`);
  }
 searchbyCatrgory(category:string):Observable<any>{
   return this.http.post(`${environment.apiUrl}/search`,{"category": category});
 }
 getOneProductDetail(productID:string):Observable<any>{
  return this.http.post(`${environment.apiUrl}/product`,{"productID":productID})
 }
 AddtoCart(producttoBuy: cart):Observable<any> {
  return this.http.post(`${environment.apiUrl}/cart`,producttoBuy)
}
//viewcart
ViewCart(producttoBuy: cart):Observable<any> {
  return this.http.post(`${environment.apiUrl}/viewcart`,producttoBuy)
}
placeorder(producttoBuy: cart):Observable<any> {
  return this.http.post(`${environment.apiUrl}/placeorder`,producttoBuy)
}
clearcart(producttoBuy: any):Observable<any> {
  return this.http.post(`${environment.apiUrl}/clearcart`,producttoBuy)
}
}
