import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService } from '../service/alert.service';
import { ServiceService } from '../service/service.service';
import { product } from './product';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  flag: boolean = false;
  cart!: any;
  catergory_id="Baby";

  constructor(private router: Router, private formBuilder: FormBuilder, private service: ServiceService, private route: ActivatedRoute, private alertService: AlertService) { }
  products!: product[];
  imputfromsearch!: string;

  ngOnInit() {
    this.service.getAllProductDetails().subscribe(obs => {
      this.products = obs;
    });

 

  }


    
 
  viewdetails(event : any){
    const productID=event;
    this.router.navigate(['/productdetail' + `/${productID}`]);
  
    }
    AddToCart(event: any) {
      try {
        const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
        if (id && localStorage.getItem("currentUser")) {
          const producttoBuy = event;
          console.log(producttoBuy);
  
          this.cart = { "userid":id, "product": producttoBuy, "quantity": 1 }
          console.log(this.cart);
          this.service.AddtoCart(this.cart).subscribe(obs => {
            console.log(obs.message);
            this.router.navigate(['/cart']);
          })
        }
  
        else {
          this.router.navigate(['/login']);
        }
      }
      catch (error) {
        this.router.navigate(['/login']);
  
      }
  
  
    }

    searchproducts(event:Event){
      const selection= (event.target as HTMLInputElement).value;
      //console.log(['/product/'+selection]);
      //route it to product page...
      const catergory_id = selection.charAt(0).toUpperCase() + selection.slice(1);
      this.router.navigate(['/category' + `/${catergory_id}`]);
      
      console.log("Routed from header event to : " +['/category' + `/${catergory_id}`]);
    }
}


