export interface product {
    _id: any;
    productname: any;

    productdescription: any;

    availablequantity: any;

    lastupdated: any;

    updatedby: any;

    productimage: any;

    productID: any;

    price:any;

    salebadge:any;

    category:any;
    
    discount:any;

}