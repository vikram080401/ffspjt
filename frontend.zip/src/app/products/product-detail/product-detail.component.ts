import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { cart } from 'src/app/cart/cart';
import { ServiceService } from 'src/app/service/service.service';
import { product } from '../product';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {


  constructor(private router: Router, private service: ServiceService, private route: ActivatedRoute) { }
  product!: product;
  cart!: any;
  ngOnInit() {

    this.route.paramMap.subscribe((data) => {
      const dt = data.get("productID")!
      this.service.getOneProductDetail(dt).subscribe(obs => {
        this.product = obs;
      })

    })

  }
  AddToCart(event: any) {
    try {
      const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if (id && localStorage.getItem("currentUser")) {
        const producttoBuy = event;
        console.log(producttoBuy);

        this.cart = {"userid":id, "product": producttoBuy, "quantity": 1 }
        console.log(this.cart);
        this.service.AddtoCart(this.cart).subscribe(obs => {
          console.log(obs.message);
          this.router.navigate(['/cart']);
        })
      }

      else {
        this.router.navigate(['/login']);
      }
    }
    catch (error) {
      this.router.navigate(['/login']);

    }


  }
}
