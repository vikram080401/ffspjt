export interface user{
    _id: any;
    firstname: any;
    lastname: any;
    email: any;
    password: any;
    phone: any;
    role: any;
    interests:any;
    address:any;
    image:any;
   
}