import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService } from 'src/app/service/alert.service';
import { ServiceService } from 'src/app/service/service.service';
import { user } from '../user';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  user!: user;
  SaveAddressForm!: FormGroup;
  form!: FormGroup;
  mygroup!: FormGroup;
  imageData!: string;
  Newaddress!: string;
  loading = false;
  submitted = false;
  isDisabled = true;
  isCancelEnabled = true;
  isEditFormEnabled = true;
  isSaveEnabled = true;
  isUploadClicked: boolean = false;
  shouldShowError: boolean = false;
  shouldShowSuccess: boolean = false;
  UPLOAD_SUCCESS_MSG = 'Upload sucessfull!';
  UPLOAD_FAILURE_MSG = 'Upload Failed!';
  constructor(private router: Router, private formBuilder: FormBuilder, private service: ServiceService, private route: ActivatedRoute, private alertService: AlertService) { }
  email!: any;
  ngOnInit() {


    this.SaveAddressForm = this.formBuilder.group({
      streetaddress: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      zipcode: ['', [Validators.required, Validators.maxLength(6), Validators.minLength(5)]]
    });
    this.form = this.formBuilder.group({

    })
    this.isDisabled = true;
    this.isCancelEnabled = true;
    this.isEditFormEnabled = true;
    this.isSaveEnabled = true;
    try {
      const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if (id && localStorage.getItem("currentUser")) {
        this.route.paramMap.subscribe((data) => {
        const email_id = data.get("id")!;

        this.service.getUserDetails(email_id).subscribe(responsedata => {
          console.log(responsedata);
          this.user = responsedata;
          console.log(this.user);

        })

      } )
    }

    else {
      this.router.navigate(['/login']);
    }
    } catch (error) {
      this.router.navigate(['/login']);

    }
  }
  get f() { return this.SaveAddressForm.controls; };
  get g() { return this.form.controls };
  onSubmit() {
    this.submitted = true;

    if (this.SaveAddressForm.invalid) {
      return;
    }
    this.isDisabled = !this.isDisabled;
    this.isEditFormEnabled = !this.isEditFormEnabled;

    this.loading = true;
    this.Newaddress = this.f['streetaddress'].value + ', ' + this.f['city'].value + ', ' + this.f['state'].value + ', ' + this.f['zipcode'].value
    this.user.address = this.Newaddress;

    this.service.updateUser(this.user).subscribe(obs => {
      if (obs.status == 200) {
        this.alertService.success('Profile Update successful', true);
        return;
      }
      else {
        this.alertService.error(obs.status, obs.message);
        return;
      }

    })



  }

  onEditClick() {
    //this.isEditButtonEnabled = !this.isEditButtonEnabled;
    this.isDisabled = !this.isDisabled;
    this.isEditFormEnabled = !this.isEditFormEnabled;
    //this.onSubmit();
  }
  canCelEdit() {
    this.isDisabled = !this.isDisabled;
    this.isEditFormEnabled = !this.isEditFormEnabled;
  }
  UploadImage() {
    this.isUploadClicked = !this.isUploadClicked;
  }
  DeleteImage() {

  }




  onFileSelect(event: Event) {
    const files = ((event.target) as HTMLInputElement);
    if (files.files?.item) {
      const file = files.files[0];
      this.form.patchValue({ image: file });
      const allowedMimeTypes = ["image/png", "image/jpeg", "image/jpg"];
      if (file && allowedMimeTypes.includes(file.type)) {
        const reader = new FileReader();
        reader.onload = () => {
          this.imageData = reader.result as string;
        };
        reader.readAsDataURL(file);
      }

    }

  }


  onUploadButton() {

    console.log("Onupload button is clicked");
    this.isUploadClicked = false;
    this.service.updateUserProfilePics(this.user.email, this.imageData).subscribe(obs => {
      if (obs.status == 200) {
        alert(this.UPLOAD_SUCCESS_MSG)
        this.shouldShowSuccess = true;

        this.user.image = this.imageData;
        this.ngOnInit();
        return;
      }
      else {
        alert(this.UPLOAD_FAILURE_MSG)

        this.shouldShowError = true;
        return;
      }

    })
    this.form.reset();
    this.imageData = "";
  }
  CancelImageUpload() {
    this.isUploadClicked = false;
  }

}

