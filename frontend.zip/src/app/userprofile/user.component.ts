import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { ServiceService } from '../service/service.service';
import { user } from './user';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private service: ServiceService, private router: Router, private route: ActivatedRoute) {

  }
  user!: user[]
  ngOnInit() {

    try {
      const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if (id && localStorage.getItem("currentUser")) {
        this.service.getUsers().subscribe((obs) => {
          this.user = obs;
        });
      }
      else {
        this.router.navigate(['/login']);
      }
    } catch (error) {
      this.router.navigate(['/login']);

    }


  }


}

/*
//---------------
 try{
      const id = JSON.parse((localStorage.getItem("currentUser")?.valueOf())!).email;
      if(id && localStorage.getItem("currentUser")){

      }
    }catch{

    }
*/