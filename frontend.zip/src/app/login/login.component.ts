import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertService } from '../service/alert.service';
import { AuthenticationService } from '../service/authentication.service';

import { ServiceService } from '../service/service.service';
import { first } from 'rxjs/operators';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  paragraph=`Folly words widow one downs few age every seven. If miss part by fact he park just shew.
  Discovered had
  get considered projection who favourable. Necessary up knowledge it tolerably. Unwilling
  departure
  education is be dashwoods or an. Use off agreeable law unwilling sir deficient curiosity
  instantly. Easy
  mind life fact with see has bore ten. Parish any chatty can elinor direct for former. Up as
  meant widow
  equal an share least.

  Depart do be so he enough talent. Sociable formerly six but handsome. Up do view time they shot.
  He
  concluded disposing provision by questions as situation. Its estimating are motionless day
  sentiments
  end. Calling an imagine at forbade. At name no an what like spot. Pressed my by do affixed he
  studied.`

  loginForm!: FormGroup;
  loading = false;
  submitted = false;
  returnUrl!: string;
  loginError!:string;
  showloginError:boolean=false;
  LOGIN_ERROR_MSG="Incorrect Username or Password!!";
  constructor(private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router, private service:ServiceService,private authenticationService: AuthenticationService,
    private alertService: AlertService) {
      if (this.authenticationService.currentUserValue) {
        this.router.navigate(['/']);
    } }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });
  this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || 'profile';
}
get f() { return this.loginForm.controls; }

onSubmit() {
  this.submitted = true;

  //this.alertService.clear();

  // stop here if form is invalid
  if (this.loginForm.invalid) {
      return;
  }
  const userid=this.f['username'].value;
  const pass=this.f['password'].value;
  this.loading = true;
  
  this.authenticationService.login(userid, pass)
  .pipe(first())
  .subscribe(
      data => {
        console.log(data);
          this.router.navigate([this.returnUrl+`/${userid}`]);
      },
      error => {
          if(error.status==404){
            this.showloginError=true;
            this.loading = false;
            this.loginError=`${this.LOGIN_ERROR_MSG}`;
            this.submitted=false;
            this.f['username'].setValue('');
            this.f['password'].setValue('');
            
          }
          this.loginError=`${this.LOGIN_ERROR_MSG}`;
          this.loading = false;
          
      });
      
}


}

/*
HttpErrorResponse
error: {status: 404, message: 'Invalid username or Password!'}
headers: HttpHeaders {normalizedNames: Map(0), lazyUpdate: null, lazyInit: ƒ}
message: "Http failure response for http://localhost:5001/api/v1/validateuser: 404 Not Found"
name: "HttpErrorResponse"
ok: false
status: 404
statusText: "Not Found"
url: "http://localhost:5001/api/v1/validateuser"
[[Prototype]]: HttpResponseBase
*/

