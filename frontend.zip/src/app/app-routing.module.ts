import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CartComponent } from './cart/cart.component';
import { HomepageComponent } from './homepage/customer/homepage/homepage.component';
import { HomepageCategoryComponent } from './homepage/homepage-category/homepage-category.component';
import { LoginComponent } from './login/login.component';
import { OrdersComponent } from './orders/orders.component';
import { ProductDetailComponent } from './products/product-detail/product-detail.component';
import { ProductsComponent } from './products/products.component';
import { RegisterComponent } from './register/register.component';
import { UserComponent } from './userprofile/user.component';
import { UserdetailsComponent } from './userprofile/userdetails/userdetails.component';

const routes: Routes = [
  {
    path:'public/*',
    redirectTo: '/public/*'
  },
  {
    path: 'order',
    component: OrdersComponent
  },
  {
    path: 'cart',
    component: CartComponent
  }
  ,
  {
    path: 'productdetail/:productID',
    component: ProductDetailComponent
  },
  {
    path: 'category/:catergory_id',
    component: HomepageCategoryComponent
  }
  ,
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'product/:id',
    component: ProductsComponent
  },
  {
    path: 'product',
    component: ProductsComponent
  },
  {
    path: 'user',
    component: UserComponent
  },
  {
    path: 'profile/:id',
    component: UserdetailsComponent
  },
  {
    path: 'profile',
    component: UserdetailsComponent
  },
  {
    path: 'register',
    component: RegisterComponent
  }
  ,
  {
    path: '',
    component: HomepageComponent
  },
  {
    path: '**',
    redirectTo: '/not-found',
    pathMatch: 'full'     
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
